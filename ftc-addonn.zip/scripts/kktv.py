import asyncio
import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger
from pyrogram.types import InlineKeyboardButton

_headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/102.0.5005.63 Safari/537.36',
    'Accept-Language': 'en'
}

kkurl = "https://api.kktv.me/v3/ipcheck"


async def fetch_kktv(Collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    KKTV检测
    :param Collector: 采集器
    :param session:
    :param proxy:
    :param reconnection: 重连次数
    :return:
    """
    try:
        async with session.get(kkurl, proxy=proxy, timeout=5) as res:
            if res.status == 200:
                resdata = await res.json()
                isallowed = resdata.get("data", {}).get("is_allowed", False)
                if isallowed:
                    Collector.info["kktv"] = "解锁"
                else:
                    Collector.info["kktv"] = "失败"
            else:
                Collector.info['kktv'] = "检测失败"
    except ClientConnectorError as c:
        logger.warning("KKTV请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_kktv(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['kktv'] = "连接错误"
    except asyncio.exceptions.TimeoutError:
        logger.warning("KKTV请求超时，正在重新发送请求......")
        if reconnection != 0:
            await fetch_kktv(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['kktv'] = "超时"


def task(Collector, session, proxy):
    return asyncio.create_task(fetch_kktv(Collector, session, proxy=proxy))


# cleaner section
def get_kktv_info(ReCleaner):
    try:
        if 'kktv' not in ReCleaner.data:
            logger.warning("采集器内无数据")
            return "N/A"
        else:
            logger.info("KKTV解锁：" + str(ReCleaner.data.get('kktv', "N/A")))
            return ReCleaner.data.get('kktv', "N/A")
    except Exception as e:
        logger.error(e)
        return "N/A"


SCRIPT = {
    "MYNAME": "KKTV",
    "TASK": task,
    "GET": get_kktv_info
}

# bot_setting_board
button = InlineKeyboardButton("✅KKTV", callback_data='✅KKTV')

if __name__ == "__main__":
    # Test code
    import sys
    import os
    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("KKTV")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)
