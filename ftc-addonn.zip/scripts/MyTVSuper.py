import asyncio
import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger

# collector section
mytvsuperurl = "https://www.mytvsuper.com/api/auth/getSession/self/"
_headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/102.0.5005.63 Safari/537.36',
}

async def fetch_mytvsuper(Collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    mytvsuper检测
    :param Collector: 采集器
    :param session: aiohttp.ClientSession()类
    :param proxy: 默认None即可
    :param reconnection: 重连次数
    :return:
    """
    try:
        async with session.get(mytvsuperurl, headers=_headers, proxy=proxy, timeout=5) as res:
            if res.status == 200:
                resdata = await res.json()
                region = resdata.get('region',"")
                if region:
                    if region == 1:
                        Collector.info['mytvsuper'] = "解锁"
                    else:
                        Collector.info['mytvsuper'] = "失败"
                else:
                    Collector.info['mytvsuper'] = "N/A"
            else:
                Collector.info['mytvsuper'] = "未知"
    except ClientConnectorError as c:
        logger.warning("mytvsuper请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_mytvsuper(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['mytvsuper'] = "连接错误"
    except asyncio.exceptions.TimeoutError:
        logger.warning("mytvsuper请求超时，正在重新发送请求......")
        if reconnection != 0:
            await fetch_mytvsuper(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['mytvsuper'] = "超时"


def task(Collector, session, proxy):
    return asyncio.create_task(fetch_mytvsuper(Collector, session, proxy=proxy))

# cleaner section
def get_mytvsuper_info(ReCleaner):
    """
    获得mytvsuper解锁信息
    :param ReCleaner:
    :return: str: 解锁信息: [解锁(地区代码)、失败、N/A]
    """
    try:
        if 'mytvsuper' not in ReCleaner.data:
            logger.warning("采集器内无数据")
            return "N/A"
        else:
            # logger.info("mytvsuper(解锁)" + str(ReCleaner.data.get('mytvsuper', "N/A")))
            return ReCleaner.data.get('mytvsuper', "N/A")
    except Exception as e:
        logger.error(e)
        return "N/A"


SCRIPT = {
    "MYNAME": "MyTVSuper",
    "TASK": task,
    "GET": get_mytvsuper_info
}

if __name__ == "__main__":
    "this is a test demo"
    import sys
    import os

    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("MyTVSuper")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)