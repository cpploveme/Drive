import asyncio
import json

import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger

# collector section
bahamut_url = "https://ani.gamer.com.tw/ajax/token.php?adID=89422&sn=14667"
bahamut_url2 = "https://ani.gamer.com.tw/ajax/token.php?adID=89422&sn=14667&device="


async def fetch_bahamut(Collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    bahamut检测
    :param Collector: 采集器
    :param session:
    :param proxy:
    :param reconnection:
    :return:
    """
    try:
        async with session.get("https://ani.gamer.com.tw/ajax/getdeviceid.php", proxy=proxy, timeout=5) as device:
            bahamut_cookie = device.cookies
            texts = await device.text()
            if len(texts) < 100:
                d = json.loads(texts)
                deviceid = d.get('deviceid')
            else:
                if texts.find("巴哈姆特電玩資訊站 - 系統異常回報"):
                    Collector.info['bahamut'] = "请求被拦截"
                else:
                    Collector.info['bahamut'] = "未知异常"
                return
        async with session.get(bahamut_url2 + deviceid, proxy=proxy, timeout=5, cookies=bahamut_cookie) as bahamut:
            if bahamut.status == 200:
                pretext = await bahamut.text()
                index = pretext.find("animeSn")
                Collector.info['bahamut'] = "解锁" if index >= 0 else "失败"
            else:
                Collector.info['bahamut'] = "N/A"
    except ClientConnectorError as c:
        logger.warning("bahamut请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_bahamut(Collector, session=session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['bahamut'] = "连接错误"
    except asyncio.exceptions.TimeoutError:
        logger.warning("bahamut请求超时，正在重新发送请求......")
        if reconnection != 0:
            await fetch_bahamut(Collector, session=session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['bahamut'] = "超时"


def task(Collector, session, proxy):
    return asyncio.create_task(fetch_bahamut(Collector, session, proxy=proxy))


# cleaner section
def get_bahamut_info(ReCleaner):
    """
    获得bahamut解锁信息
    :param ReCleaner:
    :return: str: 解锁信息: [解锁(地区代码)、失败、N/A]
    """
    try:
        if 'bahamut' not in ReCleaner.data:
            logger.warning("采集器内无数据")
            return "N/A"
        else:
            logger.info("bahamut 状态：" + str(ReCleaner.data['bahamut']))
            return ReCleaner.data['bahamut']
    except Exception as e:
        logger.error(e)
        return "N/A"


SCRIPT = {
    "MYNAME": "Bahamut",
    "TASK": task,
    "GET": get_bahamut_info
}

if __name__ == "__main__":
    "this is a test demo"
    import sys
    import os

    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("Bahamut")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)