# 脚本名称：tving解锁检测脚本
# 检测地区：韩国（KR）
# 作者：Telegram @FullTclash
# 日期：2023.2.20
# 原项目: https://github.com/lmc999/RegionRestrictionCheck
import asyncio
import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger

tvingurl = "https://api.tving.com/v2a/media/stream/info?apiKey=1e7952d0917d6aab1f0293a063697610&mediaCode=RV60891248"


async def fetch_tving(Collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    tving解锁检测
    :param Collector: 采集器
    :param session:
    :param proxy:
    :param reconnection: 重连次数
    :return:
    """
    try:
        async with session.get(url=tvingurl, proxy=proxy, timeout=5) as r:
            if r.status == 200:
                data = await r.json()
                d1 = data.get('body', {}).get('result', {}).get('message', '')
                if d1:
                    index = d1.find(r"Our service is only available in South Korea")
                    Collector.info['tving'] = "失败" if index >= 0 else "解锁"
                else:
                    Collector.info['tving'] = "未知"
            else:
                Collector.info['tving'] = "失败"

    except ClientConnectorError as c:
        logger.warning("tving请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_tving(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['tving'] = "连接错误"
            return
    except asyncio.exceptions.TimeoutError:
        if reconnection != 0:
            logger.warning("tving请求超时，正在重新发送请求......")
            await fetch_tving(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['tving'] = "超时"
            return


def task(Collector, session, proxy):
    return asyncio.create_task(fetch_tving(Collector, session, proxy=proxy))


# cleaner section
def get_tving_info(ReCleaner):
    """
    获得tving解锁信息
    :param ReCleaner:
    :return: str: 解锁信息: [解锁、失败、N/A]
    """
    try:
        if 'tving' not in ReCleaner.data:
            logger.warning("采集器内无数据: tving")
            return "N/A"
        else:
            return ReCleaner.data.get('tving', "N/A")
    except Exception as e:
        logger.error(str(e))
        return "N/A"


SCRIPT = {
    "MYNAME": "Tving",
    "TASK": task,
    "GET": get_tving_info
}

if __name__ == "__main__":
    "this is a test demo"
    import sys
    import os

    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("Tving")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)
