import asyncio
import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger


_data = {
        'contentId': '202105121370235',
        'contentType': 'Vod',
        'pin': '',
        'deviceId': 'W-60b8d30a-9294-d251-617b-c12f9d0c',
        'deviceType': 'WEB',
}
_headers = {
        'Content-Type': 'application/json',
    }

# collector section
async def fetch_nowe(collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    nowe解锁测试
    :param collector:
    :param reconnection:
    :param session:
    :param proxy:
    :return:
    """
    noweurl = 'https://webtvapi.nowe.com/16/1/getVodURL'
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(noweurl, json = _data, headers = _headers, proxy=proxy, timeout=5) as resq:
                if resq.status == 200:
                    result = await resq.json()
                    response_code = result.get('responseCode', '')
                    if response_code == 'SUCCESS' or response_code == 'PRODUCT_INFORMATION_INCOMPLETE':
                        collector.info['nowe'] = "解锁"
                    elif response_code == 'GEO_CHECK_FAIL':
                        collector.info['nowe'] = "失败"
                    else:
                        collector.info['nowe'] = "未知"
                else:
                    collector.info['nowe'] = "失败"
    except ClientConnectorError as c:
        logger.warning("nowe请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_nowe(collector, session=session, proxy=proxy, reconnection=reconnection - 1)
        else:
            collector.info['nowe'] = "连接错误"
    except asyncio.exceptions.TimeoutError:
        logger.warning("nowe请求超时，正在重新发送请求......")
        if reconnection != 0:
            await fetch_nowe(collector, session=session, proxy=proxy, reconnection=reconnection - 1)
        else:
            collector.info['nowe'] = "超时"


def task(Collector, session, proxy):
    return asyncio.create_task(fetch_nowe(Collector, session, proxy=proxy))


# cleaner section
def get_nowe_info(ReCleaner):
    """
    获取nowe解锁信息
    :return: str: 解锁信息: [解锁、失败、N/A]
    """
    try:
        if 'nowe' not in ReCleaner.data:
            logger.warning("采集器内无数据")
            return "N/A"
        else:
            # logger.info("nowe解锁：" + str(ReCleaner.data.get('nowe', "N/A")))
            return ReCleaner.data.get('nowe', "N/A")
    except Exception as e:
        logger.error(e)
        return "N/A"


SCRIPT = {
    "MYNAME": "NowE",
    "TASK": task,
    "GET": get_nowe_info
}

if __name__ == "__main__":
    "this is a test demo"
    import sys
    import os

    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("NowE")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)
