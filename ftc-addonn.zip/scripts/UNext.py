import asyncio
import aiohttp
from aiohttp import ClientConnectorError
from loguru import logger

# collector section
unexturl = "https://video-api.unext.jp/api/1/player?entity%5B%5D=playlist_url&episode_code=ED00148814&title_code=SID0028118&keyonly_flg=0&play_mode=caption&bitrate_low=1500"
_headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/102.0.5005.63 Safari/537.36',
}

async def fetch_unext(Collector, session: aiohttp.ClientSession, proxy=None, reconnection=2):
    """
    unext检测
    :param Collector: 采集器
    :param session: aiohttp.ClientSession()类
    :param proxy: 默认None即可
    :param reconnection: 重连次数
    :return:
    """
    try:
        async with session.get(unexturl, headers=_headers, proxy=proxy, timeout=5) as res:
            if res.status == 200:
                resdata = await res.json()
                responsecode = resdata.get('data',"").get('entities_data',"").get('playlist_url',"").get('result_status',"")
                if responsecode:
                    if responsecode == 467:
                        Collector.info['unext'] = "失败"
                    elif responsecode == 475:
                        Collector.info['unext'] = "解锁"
                    else:
                        Collector.info['unext'] = "未知"
                else:
                    Collector.info['unext'] = "N/A"
            else:
                Collector.info['unext'] = "未知"
    except ClientConnectorError as c:
        logger.warning("unext请求发生错误:" + str(c))
        if reconnection != 0:
            await fetch_unext(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['unext'] = "连接错误"
    except asyncio.exceptions.TimeoutError:
        logger.warning("unext请求超时，正在重新发送请求......")
        if reconnection != 0:
            await fetch_unext(Collector, session, proxy=proxy, reconnection=reconnection - 1)
        else:
            Collector.info['unext'] = "超时"

def task(Collector, session, proxy):
    return asyncio.create_task(fetch_unext(Collector, session, proxy=proxy))

# cleaner section
def get_unext_info(ReCleaner):
    """
    获得unext解锁信息
    :param ReCleaner:
    :return: str: 解锁信息: [解锁(地区代码)、失败、N/A]
    """
    try:
        if 'unext' not in ReCleaner.data:
            logger.warning("采集器内无数据")
            return "N/A"
        else:
            # logger.info("mytvsuper(解锁)" + str(ReCleaner.data.get('mytvsuper', "N/A")))
            return ReCleaner.data.get('unext', "N/A")
    except Exception as e:
        logger.error(e)
        return "N/A"


SCRIPT = {
    "MYNAME": "UNext",
    "TASK": task,
    "GET": get_unext_info
}

if __name__ == "__main__":
    "this is a test demo"
    import sys
    import os

    os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
    from libs.collector import Collector as CL, media_items

    media_items.clear()
    media_items.append("UNext")
    cl = CL()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cl.start(proxy="http://127.0.0.1:1111"))
    print(cl.info)